public class DogImpl  implements Animal {

    public void sound() {
        System.out.println("haf haf");
    }

    @Override
    public String toString() {
        return "haf haf";
    }
}
