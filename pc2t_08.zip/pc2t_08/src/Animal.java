public interface Animal {

    public abstract void sound();
}
