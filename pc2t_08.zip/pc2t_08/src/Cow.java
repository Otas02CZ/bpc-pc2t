public class Cow extends AbstractAnimal {

    @Override
    public void sound() {
        System.out.println("Mů Mů");
    }

    @Override
    public String toString() {
        return "mu mu";
    }
}
