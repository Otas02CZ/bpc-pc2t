public class Pig extends AbstractAnimal {

    @Override
    public void sound() {
        System.out.println("Chrocht Chrocht");
    }

    @Override
    public String toString() {
        return "oink oink";
    }

}
