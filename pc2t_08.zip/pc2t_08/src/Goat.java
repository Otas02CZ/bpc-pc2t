public class Goat extends AbstractAnimal {

    @Override
    public void sound() {
        System.out.println("ME-e-e-e-e");
    }

    @Override
    public String toString() {
        return "meme";
    }
}
