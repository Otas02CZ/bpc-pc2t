public class Dog extends AbstractAnimal {

    @Override
    public void sound() {
        System.out.println("Haf haf");
    }

    @Override
    public String toString() {
        return "haf haf";
    }
}
