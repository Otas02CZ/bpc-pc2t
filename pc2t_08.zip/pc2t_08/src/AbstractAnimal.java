public abstract class AbstractAnimal {

    private byte age;
    public abstract void sound();

}
