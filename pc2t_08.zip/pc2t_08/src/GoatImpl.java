public class GoatImpl implements Animal {

    public void sound() {
        System.out.println("meme");
    }

    @Override
    public String toString() {
        return "meme";
    }
}
