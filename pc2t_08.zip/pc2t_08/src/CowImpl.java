public class CowImpl implements Animal {

    public void sound() {
        System.out.println("bu bu");
    }

    @Override
    public String toString() {
        return "bu bu";
    }
}