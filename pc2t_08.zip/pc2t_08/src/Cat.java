public class Cat extends AbstractAnimal{

    @Override
    public void sound() {
        System.out.println("mnaz mnau");
    }

    @Override
    public String toString() {
        return "mnaz mnau";
    }
}
